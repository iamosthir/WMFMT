<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="description" content="Login your WFMT customer account">
    <title>WFMT - Customer Login</title>
    <link rel="stylesheet" href="<?php echo e(asset("css/bs/bootstrap.min.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("css/auth.css")); ?>">
</head>
<body>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                
                

                <div class="login-card">
                    <?php if(session()->has("success")): ?>
                        <div class="alert alert-success">
                            <?php echo e(session()->get("success")); ?>

                        </div>    
                    <?php endif; ?>
                    
                    <div class="logo">
                        <img src="<?php echo e(asset("img/logo.jpeg")); ?>" alt="Site Logo">
                    </div>

                    <h4 class="title">Customer Login</h4>
                    <div class="mt-3 login-form">
                        <form action="<?php echo e(route("customer.login")); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="row justify-content-center">
                                <div class="col-md-10 mb-4">
                                    <label for="">Email</label>
                                    <input type="email" class="form-control <?php $__errorArgs = ["email"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" placeholder="Email..." value="<?php echo e(old("email")); ?>">
                                    <?php $__errorArgs = ["email"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-10 mb-4">
                                    <label for="">Password</label>
                                    <input type="password" class="form-control <?php $__errorArgs = ["password"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" placeholder="Password...">
                                    <?php $__errorArgs = ["password"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-10 mb-4">
                                    <input type="checkbox" name="remember" id="remember"><label for="remember" class="ms-2">Remember me</label>
                                </div>
                                <div class="col-md-10 mb-4">
                                    <button class="btn btn-primary">Login</button>
                                </div>
                                <div class="col-md-10 mb-4">
                                    <a href="#">Forgot password ?</a>
                                    <div class="text-center mt-5">
                                        <a href="<?php echo e(route("customer.registration")); ?>" class="btn btn-outline-secondary">Don't have an account? Register here</a>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="<?php echo e(asset("js/bs/jquery3.6.js")); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" 
    integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset("js/bs/bootstrap.min.js")); ?>"></script>

</body>
</html><?php /**PATH C:\xampp2\htdocs\whfmt\resources\views/customer/auth/login.blade.php ENDPATH**/ ?>