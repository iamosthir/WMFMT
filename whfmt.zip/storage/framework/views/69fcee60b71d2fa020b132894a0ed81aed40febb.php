<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Resource Not Found</title>
    <link rel="stylesheet" href="<?php echo e(asset("css/main.css")); ?>">
</head>
<body>
    <div class="error-banner">
        <img src="<?php echo e(asset("img/3973481.jpg")); ?>" alt="">
        <h3>Requested Resource was not found</h3>
    </div>
</body>
</html><?php /**PATH F:\WHFMT V1.3\resources\views/errors/404.blade.php ENDPATH**/ ?>