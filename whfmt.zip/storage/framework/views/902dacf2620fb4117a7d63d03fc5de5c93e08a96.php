<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="description" content="Login your WFMT customer account">
    <title>WFMT - Customer Login</title>
    <link rel="stylesheet" href="<?php echo e(asset("css/bs/bootstrap.min.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("css/auth.css")); ?>">
</head>
<body>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                
                

                <div class="login-card">
                    <?php if(session()->has("success")): ?>
                        <div class="alert alert-success">
                            <?php echo e(session()->get("success")); ?>

                        </div>    
                    <?php endif; ?>
                    
                    <div class="logo">
                        <img src="<?php echo e(asset("img/logo.jpeg")); ?>" alt="Site Logo">
                    </div>

                    <h4 class="title">Customer Login</h4>
                    <div class="mt-3 login-form">
                        <form action="#">
                            <div class="row justify-content-center">
                                <div class="col-md-10 mb-4">
                                    <label for="">Email</label>
                                    <input type="email" class="form-control" name="email" placeholder="Email...">
                                </div>
                                <div class="col-md-10 mb-4">
                                    <label for="">Password</label>
                                    <input type="password" class="form-control" name="password" placeholder="Password...">
                                </div>
                                <div class="col-md-10 mb-4">
                                    <input type="checkbox" name="remember" id="remember"><label for="remember" class="ms-2">Remember me</label>
                                </div>
                                <div class="col-md-10 mb-4">
                                    <button class="btn btn-primary">Login</button>
                                </div>
                                <div class="col-md-10 mb-4">
                                    <a href="#">Forgot password ?</a>
                                    <div class="text-center mt-5">
                                        <a href="<?php echo e(route("customer.registration")); ?>" class="btn btn-outline-secondary">Don't have an account? Register here</a>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="<?php echo e(asset("js/bs/jquery3.6.js")); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" 
    integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset("js/bs/bootstrap.min.js")); ?>"></script>

</body>
</html><?php /**PATH F:\WHFMT V1.3\resources\views/customer/auth/login.blade.php ENDPATH**/ ?>