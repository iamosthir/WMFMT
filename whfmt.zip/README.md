<h3 align="center"><b>WMFMT.com (V 1.1)</b></h3>
<hr>
<br>
This web app is only for personal use. Not for public use. <br>
It's a customized tool to manage customers and tracking <br>
products and theires services and maintenance records for a specific business
<br>
<br>
<b>Platforms</b>
<ul>
    <li>Laravel</li>
    <li>Vue Js</li>
    <li>Bootstrap</li>
</ul>

<br>
<br>
<b>Instructions ( after download )</b>
<ul>
    <li>composer install</li>
    <li>npm install</li>
    <li>npm run dev</li>
    <li>php artisan migrate</li>
    <li>php artisan db:seed</li>
</ul>

<br>
<br>
<b>Default admin</b>
<br>
super@admin.com
<br>
pass: wmfmtadmin2022


<h1><b>Change Logs</b></h1>
<p><b>V 1.1</b></p>
<ol>
    <li>Login page changed</li>
    <li>Machine search and filtering optimized</li>
    <li>Top serial number is optional for machines database</li>
    <li>Added date range filter in Recent Service History Page</li>
</ol>

<p><b>V 1.2</b></p>
<ol>
    <li>Added new parts tracking feature</li>
    <li>Parts serach page</li>
</ol>

<p><b>V 1.3</b></p>
<ol>
    <li>Customer login</li>
    <li>Machine Search</li>
</ol>

<p><b>V 1.4</b></p>
<ol>
    <li>Customer Dashboard</li>
    <li>Excel sheet import in admin</li>
</ol>

